package com.mycom.euum.member.bean;

import lombok.Data;

@Data
public class CartListBean {
	private String sellerSpecialty;
	private String sellerDescription;
	private String sellerImage;
	private String sellerNickName;
	private int goodsNum;
	private String goodsCategory;
	private String goodsName;
	private int goodsPrice;
	private String goodsImage1;
	private String goodsImage2;
	private String goodsImage3;
}
